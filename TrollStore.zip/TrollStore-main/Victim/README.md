# Victim IPA and Cert

In order to compile a pwned TrollHelperOTA arm64 IPA, you need to provide a dev cert with the same team ID as your victim app in this directory.

```bash
./make_cert.sh <TEAM_ID>
```
