#import <Foundation/Foundation.h>

int enableJIT(NSString *bundleID);
