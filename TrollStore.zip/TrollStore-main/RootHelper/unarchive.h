@import Foundation;

extern int extract(NSString* fileToExtract, NSString* extractionPath);