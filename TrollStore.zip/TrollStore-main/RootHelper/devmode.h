#import <Foundation/Foundation.h>

BOOL checkDeveloperMode(void);
BOOL armDeveloperMode(BOOL* alreadyEnabled);