#import <UIKit/UIKit.h>

@interface TSHSceneDelegate : UIResponder <UIWindowSceneDelegate>
@property (strong, nonatomic) UIWindow * window;
@property (nonatomic, strong) UINavigationController *rootViewController;
@end