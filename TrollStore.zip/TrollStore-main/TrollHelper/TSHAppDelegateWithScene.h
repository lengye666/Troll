
#import <UIKit/UIKit.h>

@interface TSHAppDelegateWithScene : UIResponder <UIApplicationDelegate>

@end