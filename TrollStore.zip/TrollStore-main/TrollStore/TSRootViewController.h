#import <UIKit/UIKit.h>

@interface TSRootViewController : UITabBarController

@end
